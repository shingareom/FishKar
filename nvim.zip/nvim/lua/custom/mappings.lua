
local M = {}

M.dap = {
  plugin = true,
  n = {
    ["<leader>db"] = { "<cmd>DapToggleBreakpoint<CR>", "Add breakpoint at line" },
    ["<leader>dr"] = { "<cmd>DapContinue<CR>", "Start or continue the debugger" },
  },
}


vim.keymap.set("n", "<leader>gi", "<cmd>Git init<CR>", { desc = "Git Init", silent = true })
vim.keymap.set("n", "<leader>gs", "<cmd>Git<CR>", { desc = "Git Status", silent = true })
vim.keymap.set("n", "<leader>gc", "<cmd>Git commit<CR>", { desc = "Git Commit", silent = true })
vim.keymap.set("n", "<leader>gp", "<cmd>Git push<CR>", { desc = "Git Push", silent = true })
vim.keymap.set("n", "<leader>gl", "<cmd>Git pull<CR>", { desc = "Git Pull", silent = true })
vim.keymap.set("n", "<leader>gd", "<cmd>Gdiffsplit<CR>", { desc = "Git Diff", silent = true })
vim.keymap.set("n", "<leader>lg", "<cmd>LazyGit<CR>", { desc = "Open LazyGit", silent = true })

vim.api.nvim_create_user_command("Dsa", function()
  vim.cmd("cd ~/Desktop/DSA")
  print("Changed directory to ~/Desktop/DSA")
end, {})

return M

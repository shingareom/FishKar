
local ls = require("luasnip")

-- Load custom snippets
require("luasnip.loaders.from_lua").lazy_load({ paths = "~/.config/nvim/lua/custom/snippets" })
